//
//  MainView.h
//  固件升级(6.25)
//
//  Created by  on 15/6/25.
//  Copyright (c) 2015年 杨赛. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BleControl.h"
#include "ScannerDelegate.h"
#import "DFUOperations.h"
#import "MBProgressHUD.h"
@interface MainView : UIViewController<UITableViewDataSource,UITableViewDelegate,BleControlDelegate,DFUOperationsDelegate,MBProgressHUDDelegate>
{
    
    BOOL isfile;
    BOOL isComplete;//完成
    MBProgressHUD * HUD;
    BleControl * myble;
    UITableView * myTableView;
    DFUOperations *dfuOperations;
}
@property (strong, nonatomic) id <ScannerDelegate> delegate;
- (IBAction)start:(UIButton *)sender;

- (IBAction)chooseFile:(UIButton *)sender;

@end
