//
//  MainView.m
//  固件升级(6.25)
//
//  Created by  on 15/6/25.
//  Copyright (c) 2015年 杨赛. All rights reserved.
//

#import "MainView.h"
#import "DFUHelper.h"
#import "AccessFileSystem.h"
NSURL * myurl;
extern BOOL isDUF;
@interface MainView ()
{
    
}
@property (strong, nonatomic) CBPeripheral *selectedPeripheral;

@property (strong, nonatomic) DFUHelper *dfuHelper;
@property (strong, nonatomic) AccessFileSystem *fileSystem;
@property (nonatomic,strong)NSString *documentsDirectoryPath;
@property (nonatomic,strong)NSMutableArray *files;
@property (nonatomic,strong)NSMutableArray *Myfiles;

@end



@implementation MainView

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    myble = [[BleControl alloc]init];
    [myble controlSetup:1];
    myble .delegate = self;
    
    myTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, 200,200 )];
    myTableView.delegate = self;
    myTableView.dataSource = self;
    myTableView.center = self.view.center;
    [self.view addSubview:myTableView];
    [myTableView setHidden:YES];
    
    
    //DUF
    PACKETS_NOTIFICATION_INTERVAL = 10;
    dfuOperations = [[DFUOperations alloc] initWithDelegate:self];
    self.dfuHelper = [[DFUHelper alloc] initWithData:dfuOperations];
    
    
//    self.fileSystem = [[AccessFileSystem alloc]init];
//    self.documentsDirectoryPath = [self.fileSystem getDocumentsDirectoryPath];
//    self.files = [[self.fileSystem getDirectoriesAndRequiredFilesFromDocumentsDirectory] mutableCopy];
    self.Myfiles = [[NSMutableArray alloc]init];
    
   
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark bleDelegate
-(void) keyfobReady
{
     [myble enableRead: myble.activePeripheral];
    //发送设置升级模式的命令
    
    [self  sendMind];
}

-(void)myTask
{
    sleep(40);
}

-(void)sendMind
{
   
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.delegate = self;
    HUD.labelText = @"Start configuration upgrade environment....";
    [HUD showWhileExecuting:@selector(myTask) onTarget:self withObject:nil animated:YES];
    
    uint8_t send[20];
    send[0] =0x47;
    send[1] =0x00;
    send[2] =0x00;
    send[3] =0x00;
    send[4] =0x00;
    send[5] =0x00;
    send[6] =0x00;
    send[7] =0x00;
    send[8] =0x00;
    send[9] =0x00;
    send[10] =0x00;
    send[11] =0x00;
    send[12] =0x00;
    send[13] =0x00;
    send[14] =0x00;
    send[15] =0;
    
    for(int i=0;i<15;i++)
    {
        send[15] +=send[i];
    }
    send[15] =send[15] & 0xFF;
    NSData *data1 =[NSData dataWithBytes:send length:16];
    NSString *str=[self bytesToHex:data1];
    int i;
    Byte byte[128] ;
    
    NSString *write_data;
    //朽木露琪亚  朽木白哉  黑崎一护  日番谷冬狮郎  蓝染惣右介 矢胴丸莉莎
    
    NSArray *dataArr = [str componentsSeparatedByString:@" "];
    for(i=0;i<dataArr.count;i++)
    {
        write_data=[NSString stringWithFormat:@"%ld", strtoul([[dataArr objectAtIndex:i] UTF8String],0,16)];
        
        byte[i] =[write_data intValue];
    }
    NSData *d = [[NSData alloc] initWithBytes: byte length:dataArr.count-1];
    //[d getBytes:&xval length:length];
    [myble writeValue:0xfff0 characteristicUUID:0xFFF6 p:myble.activePeripheral data:d];
    
//    //再去搜索新到设备
    [self performSelector:@selector(RepeatConnect) withObject:self afterDelay:2];
}


-(NSString*)bytesToHex:(NSData*)data
{
    // Sometimes the data is bad due to threading issues.
    // Best to just catch the issues and return an empty string.
    @try {
        NSMutableString *hex = [NSMutableString stringWithCapacity:[data length]];
        const uint8_t *bytes = [data bytes];
        for (int i=0; i < [data length]; i++) {
            [hex appendFormat:@"0x%02x ", bytes[i]];
            
        }
        
        return [NSString stringWithFormat:@"%@", hex];
    }
    @catch (NSException *ex){
        return @"";
    }
}

-(void)RepeatConnect
{
    isDUF = YES;
    [myble findBLEPeripherals:2];
}


-(void) accelerometerValuesUpdated:(char)x y:(char)y z:(char)z
{
    
}
-(void) keyValuesUpdated:(char)sw
{
    
}
-(void) TXPwrLevelUpdated:(char)TXPwr
{
    
}
-(void) setButtonState
{
    
}

//pedometer //计步器绑定uuid
-(void) BindWithUUID:(NSString*)strUUID
{
    
}
//@required
-(void)SetDevice:(NSString*)device_name Status:(NSString*)status
{
    
}
-(void)Stop
{
    if(myTableView.hidden)
    [myTableView setHidden:NO];
    [myTableView reloadData];
}
-(void)ScanStop
{
    
}
-(void)DisplayRece:(unsigned char*)buf length:(int)len
{
    
}
-(void)Disconnected
{
    
}
-(void)AddTableView
{
    
}
-(void)startPhoto
{
    
}
-(void)ShowPercent:(float)battery
{
    
}
//蓝牙正常断开
-(void)WellDisconnected
{
    
}


//test
-(void)bindWithPeripheral:(CBPeripheral*)device
{
    
}

-(void)SetCenter:(CBCentralManager*)center ble:(CBPeripheral*)myPeripheral
{
//    selectedPeripheral = peripheral;
    
    
    [dfuOperations setCentralManager:center];
    
    [dfuOperations connectDevice:myPeripheral];
    
    
    [self performSelector:@selector(shengji) withObject:self afterDelay:2];
}

-(void)shengji
{
//    defaultDBPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"J074 20150601.zip"];
//     = [NSURL fileURLWithPath:defaultDBPath];
    
    //对其进行文件解压
    if(myurl)
    [self.dfuHelper unzipFiles:myurl];
    
    
    
    NSURL *  applicationURL= self.dfuHelper.applicationURL;
      NSURL *  applicationMetaDataURL= self.dfuHelper.applicationMetaDataURL;
    
    
    HUD.labelText = @"To upgrade.....";
    //升级
     [dfuOperations performDFUOnFileWithMetaData:applicationURL  firmwareMetaDataURL:applicationMetaDataURL firmwareType:APPLICATION];
}

#pragma mark Table View delegate methods

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    // Call delegate method
//    UITableViewCell * cell = [tableView cellForRowAtIndexPath:indexPath];

    if(isfile)
    {
//       NSString*  defaultDBPath  = [[self.documentsDirectoryPath stringByAppendingPathComponent:@"Inbox"] stringByAppendingPathComponent:[self.Myfiles objectAtIndex:indexPath.row]];
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *path = [paths firstObject];
        
        NSString *filePath = [path stringByAppendingPathComponent:[self.Myfiles objectAtIndex:indexPath.row]];
        myurl = [NSURL fileURLWithPath:filePath];
    }
    else
    {
    [myble connectPeripheral:[myble.peripherals objectAtIndex:indexPath.row]];
   
    [myble.CM stopScan];
    }
     [tableView setHidden:YES];
}

#pragma mark Table View Data Source delegate methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(isfile)
    {
        return self.Myfiles.count;
    }
    else
    return myble.peripherals.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
  
     if(isfile)
     cell.textLabel.text = [self.Myfiles objectAtIndex:indexPath.row];
    else
    cell.textLabel.text = [myble.arrayName objectAtIndex:indexPath.row] ;
    cell.textLabel.font  =[UIFont systemFontOfSize:10];
        
    return cell;
}

- (IBAction)start:(UIButton *)sender {
    
    if(myurl==nil)
    {
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"Please select upgrade file" message:nil delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
    }
    else
    {
    isfile = NO;
    [myble.peripherals removeAllObjects];
    [myble.arrayName removeAllObjects];
    [myble.arrayRSSI removeAllObjects];
    //扫描设备
    [myble findBLEPeripherals:2];
    }
}

- (IBAction)chooseFile:(UIButton *)sender {
    
   
//    NSString *filePath = [self.documentsDirectoryPath stringByAppendingPathComponent:@"Inbox"];
//    self.Myfiles = [[self.fileSystem getRequiredFilesFromDirectory:filePath] mutableCopy];
//    for(int i = 0; i<self.Myfiles.count;i++)
//    {
//        NSString * str = [self.Myfiles objectAtIndex:i];
//        if(![str hasSuffix:@"zip"])
//           [self.Myfiles removeObject:[self.Myfiles objectAtIndex:i]];
//    }
    [self.Myfiles removeAllObjects];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = [paths firstObject];
    NSDirectoryEnumerator *enumrator = [fileManager enumeratorAtPath:path];
    NSString *file;
    while (file = [enumrator nextObject])
    {
        if([file hasSuffix:@"zip"])
        {
            [self.Myfiles addObject:file];
        }
    }
    
    if(self.Myfiles.count==0)
    {
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"No zip upgrade file" message:nil delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
    else
    {
        isfile = YES;
        [myTableView reloadData];
        myTableView.hidden = NO;
    }
}


#pragma mark  DFUOperationsDelegate

-(void)onDeviceConnected:(CBPeripheral *)peripheral
{
    
}
-(void)onDeviceConnectedWithVersion:(CBPeripheral *)peripheral
{
    
}
-(void)onDeviceDisconnected:(CBPeripheral *)peripheral
{
//    if(!isComplete){
//    myble.CM.delegate=myble;
//    isDUF = YES;
//    [myble findBLEPeripherals:2];
//    isComplete = NO;
//    }
}

-(void)onReadDFUVersion:(int)version
{
    
}
-(void)onDFUStarted
{
    
}
-(void)onDFUCancelled
{
    
}
-(void)onSoftDeviceUploadStarted
{
    
}
-(void)onBootloaderUploadStarted
{
    
}
-(void)onSoftDeviceUploadCompleted
{
    
}
-(void)onBootloaderUploadCompleted
{
    
}
-(void)onTransferPercentage:(int)percentage
{
    NSLog(@"percentage = %d",percentage);
    HUD.labelText = [NSString stringWithFormat:@"The upgrade progress:%d%%",percentage];
}
-(void)onSuccessfulFileTranferred
{
    
    HUD.labelText = @"Upgrade is complete!";
    [self performSelector:@selector(complete) withObject:self afterDelay:1];
//    //重新设置代理
     myble.CM.delegate=myble;
    isDUF = NO;
    isComplete = YES;
}

-(void)complete
{
    [self hudWasHidden:HUD];
}
-(void)onError:(NSString *)errorMessage
{
     isfile = NO;
    myble.CM.delegate=myble;
    isDUF = YES;
    [myble findBLEPeripherals:2];
    isComplete = NO;
}

-(void)hudWasHidden:(MBProgressHUD *)hud
{
     if(HUD)
     {
         [HUD removeFromSuperview];
         HUD = nil;
     }
}

@end
